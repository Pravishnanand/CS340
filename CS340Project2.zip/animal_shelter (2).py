from pymongo import MongoClient

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self):
        USER = 'aacuser'
        PASS = 'password1234'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 30884
        DB = 'AAC'
        COL = 'animals'
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER, PASS, HOST, PORT))
        self.database = self.client[DB]
        self.collection = self.database[COL]

    def create(self, data):
        if data is not None:
            # Use insert_one to insert a single document.
            insert_result = self.collection.insert_one(data)
            if insert_result.inserted_id:
                return True
            else:
                return False
        else:
            raise ValueError("Nothing to save, because data parameter is empty")

    def read(self, criteria=None):
        if criteria is not None:
            # Use find() to retrieve documents based on criteria.
            data = list(self.collection.find(criteria, {"_id": False}))
        else:
            # Retrieve all documents if no criteria provided.
            data = list(self.collection.find({}, {"_id": False}))
        
        return data

    def update(self, criteria, new_data):
        if criteria is not None and new_data is not None:
            # Use update_one to update a single document matching the criteria.
            update_result = self.collection.update_one(criteria, {"$set": new_data})
            if update_result.modified_count > 0:
                return True
            else:
                return False
        else:
            raise ValueError("Both criteria and new_data must be provided for updating.")

    def delete(self, criteria):
        if criteria is not None:
            # Use delete_one to delete a single document matching the criteria.
            delete_result = self.collection.delete_one(criteria)
            if delete_result.deleted_count > 0:
                return True
            else:
                return False
        else:
            raise ValueError("Criteria must be provided for deletion.")
